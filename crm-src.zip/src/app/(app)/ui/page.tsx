
"use client";

// This file simply re-exports the preview component to make it available as a page route.
export { default } from '@/components/UiPreview';
