

import type { Account, Order, TeamMember, EnrichedAccount, AccountStatus } from '@/types';
import { parseISO, isValid, isAfter, subDays, differenceInDays } from 'date-fns';
import { calculateCommercialStatus, calculateLeadScore } from '@/lib/account-logic';
import { VALID_SALE_STATUSES } from '@/lib/constants';

/**
 * Processes raw accounts and interactions data to return enriched account objects for the Cartera view.
 * This version assumes all accounts are formal and exist in the accounts collection.
 */
export async function processCarteraData(
    accounts: Account[],
    orders: Order[],
    teamMembers: TeamMember[]
): Promise<EnrichedAccount[]> {
    const teamMembersMap = new Map(teamMembers.map(tm => [tm.id, tm]));
    
    const ordersByAccountId = new Map<string, Order[]>();
    for (const order of orders) {
        // Ensure the order has a valid date before processing
        const orderDate = order.createdAt ? parseISO(order.createdAt) : null;
        if (order.accountId && orderDate && isValid(orderDate)) {
            if (!ordersByAccountId.has(order.accountId)) {
                ordersByAccountId.set(order.accountId, []);
            }
            ordersByAccountId.get(order.accountId)!.push(order);
        }
    }
    
    const enrichedAccountsPromises = accounts.map(async (account): Promise<EnrichedAccount> => {
        const accountOrders = ordersByAccountId.get(account.id) || [];
        
        // Sort orders by date descending
        accountOrders.sort((a, b) => parseISO(b.createdAt!).getTime() - parseISO(a.createdAt!).getTime());

        const openTasks = accountOrders.filter(o => o.status === 'Programada' || o.status === 'Seguimiento');
        openTasks.sort((a, b) => {
            const dateAString = (a.status === 'Programada' ? a.visitDate : a.nextActionDate);
            const dateBString = (b.status === 'Programada' ? b.visitDate : b.nextActionDate);
            if(!dateAString) return 1; if(!dateBString) return -1;
            const dateA = parseISO(dateAString);
            const dateB = parseISO(dateBString);
            if (!isValid(dateA)) return 1; if (!isValid(dateB)) return -1;
            if (dateA.getTime() !== dateB.getTime()) return dateA.getTime() - dateB.getTime();
            if (a.status === 'Programada' && b.status !== 'Programada') return -1;
            if (b.status === 'Programada' && a.status !== 'Programada') return 1;
            return 0;
        });
        const nextInteraction = openTasks[0] || undefined;
        
        let status: AccountStatus;
        const historicalStatus = await calculateCommercialStatus(accountOrders);

        if (historicalStatus === 'Activo' || historicalStatus === 'Repetición' || historicalStatus === 'Inactivo') {
            status = historicalStatus;
        } else if (nextInteraction) {
            status = nextInteraction.status as 'Programada' | 'Seguimiento';
        } else if (accountOrders.length === 0) {
            status = 'Pendiente';
        } else {
            status = historicalStatus;
        }

        const lastInteractionOrder = accountOrders[0];
        const lastInteractionDate = lastInteractionOrder?.createdAt ? parseISO(lastInteractionOrder.createdAt) : undefined;
        
        const recentOrderValue = accountOrders
            .filter(o => VALID_SALE_STATUSES.includes(o.status) && o.createdAt && isValid(parseISO(o.createdAt)) && isAfter(parseISO(o.createdAt), subDays(new Date(), 30)))
            .reduce((sum, o) => sum + (o.value || 0), 0);
        const leadScore = await calculateLeadScore(status, account.potencial, lastInteractionDate, recentOrderValue);

        const successfulOrders = accountOrders.filter(o => VALID_SALE_STATUSES.includes(o.status));
        const totalSuccessfulOrders = successfulOrders.length;
        const totalValue = successfulOrders.reduce((sum, o) => sum + (o.value || 0), 0);
        
        const responsableId = account.salesRepId || account.responsableId;
        const responsable = responsableId ? teamMembersMap.get(responsableId) : undefined;
        
        return {
            ...account,
            status,
            leadScore,
            nextInteraction,
            totalSuccessfulOrders,
            totalValue,
            lastInteractionDate,
            interactions: accountOrders,
            responsableId: responsable?.id || '',
            responsableName: responsable?.name,
            responsableAvatar: responsable?.avatarUrl,
        };
    });

    const enrichedAccounts = await Promise.all(enrichedAccountsPromises);
    
    return enrichedAccounts;
}
